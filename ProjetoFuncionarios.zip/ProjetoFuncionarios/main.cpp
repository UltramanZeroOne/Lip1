
#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Funcionario {
protected:
    string nome;
    float salarioBase;
private:
    int id;
public:
    void setNome(string n) { nome = n; }
    string getNome() { return nome; }

    void setSalarioBase(float s) { salarioBase = s; }
    float getSalarioBase() { return salarioBase; }

    void setId(int i) { id = i; }
    int getId() { return id; }

    virtual void exibirInformacoes() {
        cout << "ID: " << getId() << endl;
        cout << "Nome: " << getNome() << endl;
        cout << "Salario base: " << getSalarioBase() << endl;
    }

    virtual float calcularSalarioFinal() = 0;
    virtual ~Funcionario() {}
};

class Desenvolvedor : public Funcionario {
private:
    int quantidadeDeProjetos;
public:
    void setQuantidadeDeProjetos(int q) { quantidadeDeProjetos = q; }
    int getQuantidadeDeProjetos() { return quantidadeDeProjetos; }

    float calcularSalarioFinal() override {
        return salarioBase + (500 * quantidadeDeProjetos);
    }

    void exibirInformacoes() override {
        Funcionario::exibirInformacoes();
        cout << "Tipo: Desenvolvedor" << endl;
        cout << "Projetos: " << quantidadeDeProjetos << endl;
        cout << "Salario final: " << calcularSalarioFinal() << endl;
    }
};

class Gerente : public Funcionario {
private:
    float bonusMensal;
public:
    void setBonusMensal(float b) { bonusMensal = b; }
    float getBonusMensal() { return bonusMensal; }

    float calcularSalarioFinal() override {
        return salarioBase + bonusMensal;
    }

    void exibirInformacoes() override {
        Funcionario::exibirInformacoes();
        cout << "Tipo: Gerente" << endl;
        cout << "Bonus: " << bonusMensal << endl;
        cout << "Salario final: " << calcularSalarioFinal() << endl;
    }
};

class Estagiario : public Funcionario {
private:
    int horasTrabalhadas;
public:
    void setHorasTrabalhadas(int h) { horasTrabalhadas = h; }
    int getHorasTrabalhadas() { return horasTrabalhadas; }

    float calcularSalarioFinal() override {
        return salarioBase * (horasTrabalhadas / 160.0);
    }

    void exibirInformacoes() override {
        Funcionario::exibirInformacoes();
        cout << "Tipo: Estagiario" << endl;
        cout << "Horas trabalhadas: " << horasTrabalhadas << endl;
        cout << "Salario final: " << calcularSalarioFinal() << endl;
    }
};

int main() {
    vector<Funcionario*> funcionarios;
    int qtd = 6;

    for (int i = 0; i < qtd; i++) {
        int tipo;
        cout << "Digite o tipo de funcionario (1 - Desenvolvedor, 2 - Gerente, 3 - Estagiario): ";
        cin >> tipo;

        Funcionario* f = nullptr;
        string nome;
        float salario;
        int id;

        cout << "ID: ";
        cin >> id;
        cout << "Nome: ";
        cin.ignore();
        getline(cin, nome);
        cout << "Salario base: ";
        cin >> salario;

        if (tipo == 1) {
            int projetos;
            cout << "Quantidade de projetos: ";
            cin >> projetos;
            Desenvolvedor* d = new Desenvolvedor();
            d->setId(id);
            d->setNome(nome);
            d->setSalarioBase(salario);
            d->setQuantidadeDeProjetos(projetos);
            f = d;
        } else if (tipo == 2) {
            float bonus;
            cout << "Bonus mensal: ";
            cin >> bonus;
            Gerente* g = new Gerente();
            g->setId(id);
            g->setNome(nome);
            g->setSalarioBase(salario);
            g->setBonusMensal(bonus);
            f = g;
        } else if (tipo == 3) {
            int horas;
            cout << "Horas trabalhadas: ";
            cin >> horas;
            Estagiario* e = new Estagiario();
            e->setId(id);
            e->setNome(nome);
            e->setSalarioBase(salario);
            e->setHorasTrabalhadas(horas);
            f = e;
        }

        if (f) funcionarios.push_back(f);
    }

    cout << "\n--- Informacoes dos Funcionarios ---\n";
    for (Funcionario* f : funcionarios) {
        f->exibirInformacoes();
        cout << "--------------------------\n";
    }

    for (Funcionario* f : funcionarios)
        delete f;

    return 0;
}
